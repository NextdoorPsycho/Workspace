package com.psycho.dumblefloor.trash;

public class SecondClass {
	public SecondClass() {
		System.out.println("Test");
	}

	int number = 10;

	public void test() {

	}

}
